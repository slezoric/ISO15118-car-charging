#!/bin/sh

./bin/car_charging_server
