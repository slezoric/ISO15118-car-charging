/*
 * main.c
 *
 *  Created on: 21.12.2016
 *      Author: bwpc
 */


#include <stdio.h>
#include <pthread>


pthread_t t1;
pthread_t t2;

int resource = 0;

pthread_mutex lock;

void * doSomething(void * arg);

int main(){

	//Intialisierung MUTEX
	if(pthread_mutex_init(&lock, NULL)!=0)
	{
		printf("Mutex Initialization failed");
		return 1;
	}

	pthread_create(&t1, NULL, doSomething, NULL);
	pthread_create(&t2, NULL, doSomething, NULL);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	//Mutex destroy
	pthread_mutex_destroy(&lock);

	return 0;
}

void* doSomething(void * arg)
{

	//Lock code
	pthread_mutex_lock(&lock);

	unsigned long i = 0;

	resource = resource +1;

	printf("Started Thread: %d \n", resource);
	fflush(stdout);

	for(i=0; i<0xFFFFFFFF; i++);

	printf("Finished Thread: %d \n", resource);
	fflush(stdout);

	//Unlock code
	pthread_mutex_unlock(&lock);
	return NULL;
}
