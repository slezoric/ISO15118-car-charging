/*
 * main.c
 *
 *  Created on: 07.12.2016
 *      Author: bwpc
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

void * funktion_thread1(void * parameter);
void * funktion_thread2(void * parameter);

int ret;

int main(){

	pthread_t thread1, thread2;

	char * msg1 = "Erster Thread";
	char * msg2 = "Zweiter Thread";

	pthread_create(&thread1, NULL, funktion_thread1, (void *)msg1);
	pthread_create(&thread2, NULL, funktion_thread2, (void *)msg2);

	pthread_t selfid = pthread_self();
	printf("Haupt Thread ID: %u \n", selfid);
	fflush(stdout);


	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);



	return 0;
}

void * funktion_thread1(void * parameter){
	char *msg;
	msg = (char *)parameter;
	int i;
	for(i=0; i<10; i++)
	{
		pthread_t selfid = pthread_self();
		printf("Thread ID: %u", selfid);
		printf("%s %i \n", msg, i);
		fflush(stdout);
		sleep(1);
		if(i == 3)
		{

			ret = 10;
			pthread_exit(&ret);
		}
	}

	return NULL;
}

void * funktion_thread2(void * parameter){
	char *msg;
	msg = (char *)parameter;
	int i;
	for(i=0; i<10; i++)
	{
		pthread_t selfid = pthread_self();
		printf("Thread ID: %u", selfid);
		printf("%s %i \n", msg, i);
		fflush(stdout);
		sleep(1);
	}

	return NULL;
}

